-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 22-Jul-2021 às 20:44
-- Versão do servidor: 10.4.13-MariaDB
-- versão do PHP: 7.3.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `agenda`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tblista`
--

CREATE TABLE `tblista` (
  `cod_pessoa` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `sobrenome` varchar(200) NOT NULL,
  `endereco` varchar(150) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `telefone` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tblista`
--

INSERT INTO `tblista` (`cod_pessoa`, `nome`, `sobrenome`, `endereco`, `cidade`, `telefone`) VALUES
(4, 'Leandro ', 'Corrêa', 'Rua Maranhao, 256, Centro', 'Ourinhos/SP', 23659899),
(5, 'Andre', 'Marques', 'Rua Duque de Caxias, 198,Centro', 'Ourinhos/SP', 259898989),
(6, 'Marcelo ', 'Ramos', 'Rua Alcides Claros, 563, Centro', 'Ourinhos/SP', 56698799);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `tblista`
--
ALTER TABLE `tblista`
  ADD PRIMARY KEY (`cod_pessoa`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
