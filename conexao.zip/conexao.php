<?php
$servidor= "localhost";
$dbusuario="root";
$dbname="agenda";
$dbsenha="";
$conn = mysqli_connect($servidor, $dbusuario, $dbsenha, $dbname);

	if(!$conn){
		die("conexão falhou: " . mysqli_connect_error());
		
	}
	
?>