<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8"/>
<link rel="stylesheet" href="estilo.css"/>
<body bgcolor="lavender">
<title> Pesquisar </title>
<?php


$pesquisa = $_POST['busca'] ?? '';


	include "conexao.php";
	
	$sql = "SELECT * FROM tblista WHERE nome LIKE '%$pesquisa%'";

	$dados = mysqli_query($conn, $sql);
	
	?>
	
	

<h1> Pesquisar </h1>

<form  class="form-inline" action="pesquisar.php" method="POST">
<input type="Search" placeholder="Nome"  name="busca" autofocus>
<input class="button" type="submit" value="Procurar"> <br><br>



<table width="80%" border="1" class="table">

<tr>	<th scope="col">Código</th>
        <th scope="col">Nome</th>
        <th scope="col">Sobrenome</th>
		<th scope="col">Endereço</th>
        <th scope="col">Cidade</th>
        <th scope="col">Telefone</th>
		<th scope="col">Funções</th>
    </tr>
	<br>
	<?php
	
	while ($linha = mysqli_fetch_assoc($dados)) {
		$cod_pessoa = $linha['cod_pessoa'];
		$nome = $linha['nome'];
		$sobrenome = $linha['sobrenome'];
		$endereco = $linha['endereco'];
		$cidade = $linha['cidade'];
		$telefone = $linha['telefone'];
		
		echo "<tr>
        <th scope='row'>$cod_pessoa</th>
		<td>$nome</td>
        <td>$sobrenome</td>
        <td>$endereco</td>
		<td>$cidade</td>
		<td>$telefone</td>
		<td>
		<a href='agenda_edit.php?id=$cod_pessoa' class='btn'>Editar </a>
		<a href='apaga_cont.php?id=$cod_pessoa' class='btn'> Excluir </a>
		
		</td>
		
</tr>";

	}
	

?>

	   
	   
</table>
<br><br>
<center> <h2> <a href="home.php" class="BUTTON"> Voltar </a> </center> </h2></center>


	



</head>
</html>