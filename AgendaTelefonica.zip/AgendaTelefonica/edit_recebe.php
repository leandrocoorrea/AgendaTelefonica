<?php 

include"conexao.php";

$id = $_POST['id'];
$nome = $_POST["nome"];
$sobrenome = $_POST["sobrenome"];
$endereco = $_POST["endereco"];
$cidade = $_POST["cidade"];
$telefone = $_POST["telefone"];
$conn = mysqli_connect($servidor,$dbusuario,$dbsenha,$dbname);

mysqli_select_db($conn,'$dbname');
// $sql = "INSERT INTO tblista(nome,sobrenome,endereco,cidade,telefone) VALUES ('$nome','$sobrenome', '$endereco', '$cidade', '$telefone')";

$sql = "UPDATE tblista set nome='$nome' ,sobrenome='$sobrenome',endereco='$endereco',cidade='$cidade',telefone='$telefone' WHERE cod_pessoa = $id";
 if (mysqli_query($conn, $sql)) {
	 echo "<script>alert(' Alterado com Sucesso!'); window.location = 'agenda.php';</script>";
	 
 }else{
		echo "Aconteceu um erro";
 }		
		
	 mysqli_close($conn);
 
?>