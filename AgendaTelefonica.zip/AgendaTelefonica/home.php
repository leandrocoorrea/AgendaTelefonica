<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<link rel="stylesheet" href="estilo.css"/>
<body><br><br><br>
<center>  <img src="agenda.jpg"  alt="some text" width=200 height=200> </center>

<title> Home </title>


<center>
<body bgcolor="lavender">
<font  face="Verdana">
<br><br><br>

<h3> <b> Sistema de agenda telefônica </b></h3>


<h1> <a href="agenda.php"> Cadastrar telefone </a> </h1>
<h1> <a href="pesquisar.php"> Pesquisar </a> </h1>

</font>


</head>
</html>