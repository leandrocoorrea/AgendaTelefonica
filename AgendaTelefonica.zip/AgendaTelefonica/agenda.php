<!DOCTYPE html>

<html>
<head>
<meta charset="UTF-8"/>
<link rel="stylesheet">

<title> Agenda telefônica </title>

<center>
<h1><u> Agenda </u></h1>

<head>
<body bgcolor="lavender">
	<form method="post"	action="recebe.php">
		Nome: <br>
		<input type="text" name="nome" required> <br>
		Sobrenome: <br>
		<input type="text" name="sobrenome" required><br>
		Endereço: <br>
		<input type="text" name="endereco"><br>
		Cidade: <br>
		<input type="text" name="cidade"><br>
		Telefone: <br>
		<input type="text" name="telefone" required><br>

<center> <br>
		<input class="BUTTON" type="submit" value="Enviar"><br><br><br>
		<h2> <a href="home.php" class="BUTTON"> Voltar </a> </center> </h2>

</center>
</center>
</head>
</body>
</html>