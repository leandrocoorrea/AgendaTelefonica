<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<link rel="stylesheet" href="estilo.css"/>

<title> Excluir cadastro </title>


<center>
<h1><u> Excluir contato </u></h1>

<head>
<body>

<?php
	
	include "conexao.php";
	$id= $_GET['id'] ?? '';
	$sql = "SELECT * FROM tblista WHERE cod_pessoa = $id";
	
	$dados = mysqli_query($conn, $sql);
	$linha = mysqli_fetch_assoc($dados);
	


?>
	<form method="POST"	action="apaga.cont.php">
		Nome: <br>
		<input type="text" name="nome" required value="<?php echo $linha['nome']; ?>"><br>
		Sobrenome: <br>
		<input type="text" name="sobrenome" value="<?php echo $linha['sobrenome']; ?>"><br>
		Endereço: <br>
		<input type="text" name="endereco"  value="<?php echo $linha['endereco']; ?>"><br>
		Cidade: <br>
		<input type="text" name="cidade" value="<?php echo $linha['cidade']; ?>"><br>
		Telefone: <br>
		<input type="text" name="telefone" value="<?php echo $linha['telefone']; ?>"><br>
<br><br>
		<input type="submit" class="btn" value="Excluir contato">
		<input type="hidden" name="id" value="<?php echo $linha['cod_pessoa']?>">
<center> <br>
		<h2><a href="pesquisar.php" class="BUTTON"> Voltar </a> </center> </h2>

</center>
</center>
</head>
</html>