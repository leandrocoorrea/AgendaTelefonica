<?php 

include"conexao.php";?>
<html>
<body>
<?php
$id =$_POST["id"];
$nome = $_POST["nome"];
$sobrenome = $_POST["sobrenome"];
$endereco = $_POST["endereco"];
$cidade = $_POST["cidade"];
$telefone = $_POST["telefone"];
$conn = mysqli_connect($servidor,$dbusuario,$dbsenha,$dbname);

mysqli_select_db($conn,'$dbname');
$sql = "INSERT INTO tblista(nome,sobrenome,endereco,cidade,telefone) VALUES ('$nome','$sobrenome', '$endereco', '$cidade', '$telefone')";
 if (mysqli_query($conn, $sql)) {
	 echo "<script>alert(' Cadastrado com Sucesso!'); window.location = 'agenda.php';</script>";
	 
 }else{
		echo "Aconteceu um erro";
 }		
		
	 mysqli_close($conn);
 
?>
</body>
</html>