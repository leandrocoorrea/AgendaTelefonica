<?php 

include"conexao.php";

$id = $_POST['id'];



$conn = mysqli_connect($servidor,$dbusuario,$dbsenha,$dbname);


$sql = "DELETE from tblista WHERE cod_pessoa ='$id'";
 if (mysqli_query($conn, $sql)) {
	 echo "<script>alert(' Excluido com Sucesso!'); window.location = 'pesquisar.php';</script>";
	 
 }else{
		echo "Aconteceu um erro";
 }		
		
	 mysqli_close($conn);
 
?>